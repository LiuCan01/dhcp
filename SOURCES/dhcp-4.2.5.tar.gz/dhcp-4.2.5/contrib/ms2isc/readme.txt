Copyright: please read the top of the source code.

Usage:
Objective: please read the help screen by executing the program without any 
           parameter.

Revision:
SMC: Shu-Min Chang

Who When   What
--- ------ --------------------------------------------------------------------
SMC 021107 Initial release Version 1.0 to ISC DHCP repository
SMC 030129 Fixed inclusion range calculation by sorting exclusion before
           passing to FindInclusionRanges
SMC 030228 release 1.0.1 to ISC DHCP repository
